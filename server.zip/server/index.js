const express = require("express");
require("dotenv").config();
const app = express();
const mongoConnection = require("./DB");
const cors = require("cors");
const authRoutes = require('./routes/authRoutes');
const profileRoutes = require('./routes/profileRoutes');
const trackRoutes = require('./routes/trackRoutes');
const chatRoutes = require('./routes/chatRoutes');
const maternityRoutes = require('./routes/maternityRoutes');
const gameRoutes = require('./routes/gameRoutes');

app.use(express.json());
mongoConnection();
app.use(cors());

const PORT = 7001;

app.get("/", (req, res) => {
    res.send("Backend working");
});

app.use('/api/auth', authRoutes);
app.use('/api/profile', profileRoutes);
app.use('/api/track', trackRoutes);
app.use('/api/chat', chatRoutes);
app.use('/api/maternity', maternityRoutes);
app.use('/api/games', gameRoutes);

app.listen(PORT, () => {
    console.log(`Server: http://localhost:${PORT}`);
});

