require("dotenv").config();

const GEN_AI_KEY = process.env.GEMINI_API_KEY;

fetch(
    `https://generativelanguage.googleapis.com/v1/models/gemini-pro:generateContent?key=${GEN_AI_KEY}`,
    {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify({
            contents: [
                {
                    parts: [{ text: "Hello" }]
                }
            ]
        })
    }
)
    .then(async res => {
        const data = await res.json();
        console.log(data);
    })
    .catch(err => console.log(err));
