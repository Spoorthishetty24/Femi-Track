const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const habitSchema = new mongoose.Schema({
  exercise: { type: Boolean, default: false },
  waterIntake: { type: Number, default: 0 }, // liters
  sleepHours: { type: Number, default: 0 },
  meditation: { type: Boolean, default: false },
  mood: { type: String, default: null }, // happy, sad, etc.
  symptoms: [{ type: String }], // cramps, headache
  flow: { type: String, enum: ['none', 'light', 'medium', 'heavy'], default: 'none' },
  pain: { type: Number, min: 0, max: 5, default: 0 },
  aiInsights: [{
    type: { type: String }, // 'maternity' or 'nutrition'
    content: { type: String },
    time: { type: Date, default: Date.now }
  }],
  date: { type: Date, default: Date.now }
});

const notificationSchema = new mongoose.Schema({
  type: String, // "cycle_prediction", "nutrition_tip"
  message: String,
  read: { type: Boolean, default: false },
  date: { type: Date, default: Date.now }
});

const userSchema = new mongoose.Schema({
  // Authentication
  email: {
    type: String,
    required: [true, 'Email required'],
    unique: true,
    lowercase: true,
    match: [/^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/, 'Invalid email']
  },
  password: {
    type: String,
    required: [true, 'Password required'],
    minlength: [6, 'Password min 6 chars']
  },
  pin: {
    type: String,
    required: false,
    default: null
  },

  // Profile (BMI calculation)
  profile: {
    name: { type: String, required: [true, 'Name required'] },
    age: { type: Number, min: [13, 'Age min 13'], max: [60, 'Age max 60'] },
    height: { type: Number, min: [100, 'Height min 100cm'] }, // cm
    weight: { type: Number, min: [30, 'Weight min 30kg'] }, // kg
    bmi: {
      type: Number,
      min: [10, 'BMI min 10'],
      max: [50, 'BMI max 50']
    }
  },

  // Gamification
  gamification: {
    points: { type: Number, default: 0 },
    streak: { type: Number, default: 0 },
    longestStreak: { type: Number, default: 0 },
    dailyGoal: { type: Number, default: 100 },
    level: { type: Number, default: 1 },
    badges: [{
      name: String,
      icon: String,
      date: { type: Date, default: Date.now },
      description: String
    }],
    gameLevels: {
      candy: { type: Number, default: 1 },
      shooting: { type: Number, default: 1 },
      sling: { type: Number, default: 1 },
      memory: { type: Number, default: 1 },
      defender: { type: Number, default: 1 }
    }
  },

  // Habits & Tracking
  dailyHabits: [habitSchema],
  notifications: [notificationSchema],

  // Cycle/Period Info (questionnaire answers)
  cycleInfo: {
    lastPeriodDate: Date,
    cycleLength: { type: Number, default: 28, min: 21, max: 45 },
    periodLength: { type: Number, default: 5, min: 2, max: 10 },
    flowIntensity: { type: String, enum: ['light', 'medium', 'heavy'], default: 'medium' },
    painLevel: { type: Number, min: 0, max: 5, default: 2 },
    regularCycle: { type: Boolean, default: true },
    symptoms: [{ type: String }],
    birthControlUsing: { type: Boolean, default: false },
    birthControlType: { type: String },
    healthConditions: [{ type: String }],
    isPregnant: { type: Boolean, default: false },
    pregnancyStartDate: { type: Date },
    tryingToConceive: { type: Boolean, default: false },
    setupComplete: { type: Boolean, default: false },
    aiTipsCount: { type: Number, default: 0 },
    lastTipsResetDate: { type: Date, default: Date.now }
  },

  // Preferences
  preferences: {
    notifications: { type: Boolean, default: true },
    unit: { type: String, enum: ['metric', 'imperial'], default: 'metric' },
    language: { type: String, default: 'en' },
    theme: { type: String, enum: ['light', 'dark'], default: 'light' }
  },

  // Privacy & Security
  isActive: { type: Boolean, default: true },
  lastLogin: Date,
  loginAttempts: { type: Number, default: 0 },
  isVerified: { type: Boolean, default: false },
  verificationToken: String
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// Virtual for BMI calculation
userSchema.virtual('calculatedBMI').get(function () {
  if (!this.profile.height || !this.profile.weight) return null;
  const heightM = this.profile.height / 100;
  return parseFloat((this.profile.weight / (heightM * heightM)).toFixed(2));
});

// Password hashing & Leveling logic
userSchema.pre('save', async function () {
  // Update Level based on points (5000 pts per level)
  if (this.isModified('gamification.points')) {
    this.gamification.level = Math.floor(this.gamification.points / 5000) + 1;
  }

  if (!this.isModified('password')) return;
  this.password = await bcrypt.hash(this.password, 12);
});

// Methods
userSchema.methods.comparePassword = async function (password) {
  return await bcrypt.compare(password, this.password);
};

userSchema.methods.comparePin = async function (pin) {
  return await bcrypt.compare(pin, this.pin);
};

module.exports = mongoose.model('User', userSchema);
