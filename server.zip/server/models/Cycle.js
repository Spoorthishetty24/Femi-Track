const mongoose = require('mongoose');

const symptomSchema = new mongoose.Schema({
  name: {
    type: String,
    enum: ['cramps', 'headache', 'bloating', 'mood-swings', 'fatigue', 'acne', 'breast-tenderness', 'other'],
    required: true
  },
  intensity: { type: Number, min: 1, max: 5, required: true },
  duration: Number, // days
  notes: String,
  date: { type: Date, default: Date.now }
});

const nutritionSchema = new mongoose.Schema({
  calories: Number,
  protein: Number,
  carbs: Number,
  fats: Number,
  phaseRecommendation: String // "iron-rich", "high-protein", etc.
});

const cycleSchema = new mongoose.Schema({
  // Core cycle data
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },

  // Dates & Duration
  startDate: { type: Date, required: true },
  endDate: Date,
  cycleLength: { type: Number, min: 21, max: 35 },
  periodLength: { type: Number, min: 2, max: 8 },

  // Phase detection
  phase: {
    type: String,
    enum: ['menstrual', 'follicular', 'ovulation', 'luteal', 'pregnancy'],
    required: true
  },
  maternityWeek: Number, // Week of pregnancy

  // Symptoms tracking
  symptoms: [symptomSchema],
  flowIntensity: { type: Number, min: 1, max: 5 },
  mood: {
    type: String,
    enum: ['happy', 'sad', 'anxious', 'calm', 'irritable']
  },

  // Health metrics
  temperature: Number, // Basal body temp
  heartRate: Number,
  bloodPressure: String, // "120/80"

  // Nutrition & habits
  nutrition: nutritionSchema,
  exercise: String,
  sleepHours: Number,
  waterIntake: Number,

  // Gamification
  pointsEarned: { type: Number, default: 25 },
  streakBonus: Number,

  // AI insights
  aiInsights: [{
    type: String,
    confidence: Number
  }],

  notes: String,

  // Predictions
  predictedNextPeriod: Date,
  fertileWindow: [Date]
}, {
  timestamps: true
});

module.exports = mongoose.model('Cycle', cycleSchema);
