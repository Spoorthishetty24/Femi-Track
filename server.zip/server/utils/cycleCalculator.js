const calculateCycleData = (lastPeriodDate, cycleLength = 28, periodLength = 5) => {
    if (!lastPeriodDate) return null;

    const lastDate = new Date(lastPeriodDate);
    const today = new Date();

    // Calculate days passed since last period started
    const diffTime = Math.abs(today - lastDate);
    const dayOfCycle = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    // Next period prediction
    const nextPeriodDate = new Date(lastDate);
    nextPeriodDate.setDate(lastDate.getDate() + cycleLength);

    // Fertile window (typically 14 days before next period, +/- 2 days)
    const ovulationDay = cycleLength - 14;
    const fertileStartDate = new Date(lastDate);
    fertileStartDate.setDate(lastDate.getDate() + (ovulationDay - 5));
    const fertileEndDate = new Date(lastDate);
    fertileEndDate.setDate(lastDate.getDate() + (ovulationDay + 1));

    // Phase detection
    let currentPhase = '';
    const daysUntilNext = Math.ceil((nextPeriodDate - today) / (1000 * 60 * 60 * 24));

    if (dayOfCycle <= periodLength) {
        currentPhase = 'Menstrual';
    } else if (dayOfCycle < ovulationDay - 5) {
        currentPhase = 'Follicular';
    } else if (dayOfCycle >= ovulationDay - 5 && dayOfCycle <= ovulationDay + 1) {
        currentPhase = 'Ovulation';
    } else {
        currentPhase = 'Luteal';
    }

    // Pregnancy probability
    let pregnancyChance = 'Low';
    if (dayOfCycle >= ovulationDay - 5 && dayOfCycle <= ovulationDay + 1) {
        pregnancyChance = 'High';
    } else if (dayOfCycle >= ovulationDay - 6 && dayOfCycle <= ovulationDay + 2) {
        pregnancyChance = 'Medium';
    }

    return {
        dayOfCycle,
        currentPhase,
        nextPeriodDate,
        daysUntilNext,
        fertileWindow: {
            start: fertileStartDate,
            end: fertileEndDate
        },
        pregnancyChance,
        isPeriodDay: dayOfCycle <= periodLength,
        isFertileDay: dayOfCycle >= ovulationDay - 5 && dayOfCycle <= ovulationDay + 1
    };
};

module.exports = calculateCycleData;
