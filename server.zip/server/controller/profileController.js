const User = require('../models/User');
const calculateCycleData = require('../utils/cycleCalculator');

// GET /api/profile/:userId
exports.getProfile = async (req, res) => {
    console.log(`[PROFILE] Fetching profile for user: ${req.params.userId}`);
    try {
        const user = await User.findById(req.params.userId).select('-password -pin');
        if (!user) {
            console.log(`[PROFILE] User not found during fetch: ${req.params.userId}`);
            return res.status(404).json({ success: false, error: 'User not found' });
        }

        // Ensure the daily AI tip counter is fresh when the profile is requested
        // (previous logic only reset during /ai-tip calls, which prevented the
        // button from re-enabling until the user attempted a tip). This mirrors
        // the check found in maternityController.getAITip.
        const todayStr = new Date().toISOString().split('T')[0];
        const lastResetStr = user.cycleInfo.lastTipsResetDate
            ? new Date(user.cycleInfo.lastTipsResetDate).toISOString().split('T')[0]
            : "";
        if (todayStr !== lastResetStr) {
            user.cycleInfo.aiTipsCount = 0;
            user.cycleInfo.lastTipsResetDate = new Date();
            // persist changes so subsequent requests also see the reset
            await user.save();
        }

        console.log(`[PROFILE] Found user: ${user.email}`);
        res.json({
            success: true,
            user: {
                id: user._id,
                email: user.email,
                profile: user.profile,
                cycleInfo: user.cycleInfo,
                dailyHabits: user.dailyHabits,
                gamification: user.gamification,
                preferences: user.preferences,
                createdAt: user.createdAt
            }
        });
    } catch (error) {
        console.error('Get profile error:', error);
        res.status(500).json({ success: false, error: error.message });
    }
};

// PUT /api/profile/:userId
exports.updateProfile = async (req, res) => {
    console.log(`[PROFILE] Updating profile for user: ${req.params.userId}`);
    try {
        const { name, age, height, weight } = req.body;
        console.log("Update data:", { name, age, height, weight });

        // Build update object
        const updateFields = {};
        if (name) updateFields['profile.name'] = name;
        if (age) updateFields['profile.age'] = parseInt(age);
        if (height) updateFields['profile.height'] = parseInt(height);
        if (weight) updateFields['profile.weight'] = parseInt(weight);

        // Calculate BMI if height and weight are available
        const h = parseInt(height);
        const w = parseInt(weight);
        if (h && w) {
            const heightM = h / 100;
            updateFields['profile.bmi'] = parseFloat((w / (heightM * heightM)).toFixed(2));
        } else if (h || w) {
            // One of them changed, fetch the other from DB
            const existingUser = await User.findById(req.params.userId).select('profile');
            if (existingUser) {
                const finalH = h || existingUser.profile?.height;
                const finalW = w || existingUser.profile?.weight;
                if (finalH && finalW) {
                    const heightM = finalH / 100;
                    updateFields['profile.bmi'] = parseFloat((finalW / (heightM * heightM)).toFixed(2));
                }
            }
        }

        const user = await User.findByIdAndUpdate(
            req.params.userId,
            { $set: updateFields },
            { new: true, runValidators: false }
        ).select('-password -pin');

        if (!user) {
            console.log(`[PROFILE] User not found: ${req.params.userId}`);
            return res.status(404).json({ success: false, error: 'User not found' });
        }

        console.log(`[PROFILE] Updated success for: ${user.email}`);
        res.json({
            success: true,
            message: 'Profile updated',
            user: {
                id: user._id,
                email: user.email,
                name: user.profile.name,
                age: user.profile.age,
                height: user.profile.height,
                weight: user.profile.weight,
                bmi: user.profile.bmi
            }
        });
    } catch (error) {
        console.error('Update profile error:', error);
        res.status(500).json({ success: false, error: error.message });
    }
};

// PUT /api/profile/:userId/cycle-setup
exports.saveCycleSetup = async (req, res) => {
    try {
        const {
            lastPeriodDate,
            cycleLength,
            periodLength,
            flowIntensity,
            painLevel,
            regularCycle,
            symptoms,
            birthControlUsing,
            birthControlType,
            healthConditions,
            isPregnant,
            tryingToConceive
        } = req.body;

        const user = await User.findByIdAndUpdate(
            req.params.userId,
            {
                $set: {
                    'cycleInfo.lastPeriodDate': lastPeriodDate ? new Date(lastPeriodDate) : null,
                    'cycleInfo.cycleLength': cycleLength || 28,
                    'cycleInfo.periodLength': periodLength || 5,
                    'cycleInfo.flowIntensity': flowIntensity || 'medium',
                    'cycleInfo.painLevel': painLevel !== undefined ? painLevel : 2,
                    'cycleInfo.regularCycle': regularCycle !== undefined ? regularCycle : true,
                    'cycleInfo.symptoms': symptoms || [],
                    'cycleInfo.birthControlUsing': birthControlUsing || false,
                    'cycleInfo.birthControlType': birthControlType || '',
                    'cycleInfo.healthConditions': healthConditions || [],
                    'cycleInfo.isPregnant': isPregnant || false,
                    'cycleInfo.tryingToConceive': tryingToConceive || false,
                    'cycleInfo.setupComplete': true
                },
                // $inc: { 'gamification.points': 100 }
            },
            { new: true, runValidators: false }
        ).select('-password -pin');

        if (!user) {
            return res.status(404).json({ success: false, error: 'User not found' });
        }

        res.json({
            success: true,
            message: 'Cycle setup saved!',
            cycleInfo: user.cycleInfo,
            points: user.gamification.points
        });
    } catch (error) {
        console.error('Cycle setup error:', error);
        res.status(500).json({ success: false, error: error.message });
    }
};

// GET /api/profile/dashboard/:userId
exports.getDashboard = async (req, res) => {
    try {
        const userId = req.params.userId;
        const user = await User.findById(userId).select('-password -pin');

        if (!user) {
            return res.status(404).json({ success: false, error: 'User not found' });
        }

        // 0. Update Notifications (Auto-generate if needed)
        const unreadCount = user.notifications.filter(n => !n.read).length;

        // Auto-generate some essential notifications if missing
        const cycleData = calculateCycleData(
            user.cycleInfo?.lastPeriodDate,
            user.cycleInfo?.cycleLength,
            user.cycleInfo?.periodLength
        );

        if (cycleData && user.preferences.notifications) {
            const now = new Date();
            const todayStr = now.toDateString();

            // Check for "Period Soon" alert (if 2 days away)
            if (cycleData.daysUntilNext <= 2 && cycleData.daysUntilNext > 0) {
                const existingAlert = user.notifications.find(n => n.type === 'period_soon' && new Date(n.date).toDateString() === todayStr);
                if (!existingAlert) {
                    user.notifications.push({
                        type: 'period_soon',
                        message: `Your period is predicted to start in ${cycleData.daysUntilNext} days. Stay prepared! 🌸`,
                        read: false
                    });
                }
            }

            // Check for "Ovulation" alert
            if (cycleData.isFertileDay) {
                const existingAlert = user.notifications.find(n => n.type === 'ovulation' && new Date(n.date).toDateString() === todayStr);
                if (!existingAlert) {
                    user.notifications.push({
                        type: 'ovulation',
                        message: `You are in your fertile window today! ✨`,
                        read: false
                    });
                }
            }

            if (user.isModified('notifications')) {
                await user.save();
            }
        }

        // 2. Get Today's Habit Log
        const today = new Date();
        today.setHours(0, 0, 0, 0);

        const todayLog = user.dailyHabits.find(log => {
            const logDate = new Date(log.date);
            logDate.setHours(0, 0, 0, 0);
            return logDate.getTime() === today.getTime();
        }) || {
            waterIntake: 0,
            sleepHours: 0,
            exercise: false,
            meditation: false,
            mood: null,
            symptoms: [],
            flow: 'none',
            pain: 0
        };

        // 3. Get Recent Activity (Last 5 days of logs)
        const recentActivity = [...user.dailyHabits]
            .sort((a, b) => new Date(b.date) - new Date(a.date))
            .slice(0, 5);

        // 4. Recommendations based on phase
        const recommendations = [];
        if (cycleData) {
            if (cycleData.currentPhase === 'Menstrual') {
                recommendations.push({ title: 'Iron Rich Food', content: 'Spinach and lentils are good for you now.', icon: '🥗' });
                recommendations.push({ title: 'Light Yoga', content: 'Helps with cramps and mood.', icon: '🧘‍♀️' });
            } else if (cycleData.currentPhase === 'Ovulation') {
                recommendations.push({ title: 'High Energy', content: 'Great time for intense workouts!', icon: '⚡' });
                recommendations.push({ title: 'Stay Hydrated', content: 'Drink plenty of water during ovulation.', icon: '💧' });
            } else if (cycleData.currentPhase === 'Follicular') {
                recommendations.push({ title: 'New Beginnings', content: 'Focus on new goals and high productivity.', icon: '🌱' });
            } else if (cycleData.currentPhase === 'Luteal') {
                recommendations.push({ title: 'Slow Down', content: 'Opt for comfort and self-care today.', icon: '🍵' });
            }
        }

        res.json({
            success: true,
            user: {
                id: user._id,
                email: user.email,
                name: user.profile?.name || 'User',
                bmi: user.profile?.bmi || 22.5,
                points: user.gamification?.points || 0,
                streak: user.gamification?.streak || 0,
                level: user.gamification?.level || 1,
                unreadNotifications: user.notifications.filter(n => !n.read).length,
                cycleSetupComplete: user.cycleInfo?.setupComplete || false
            },
            todayLog,
            cycleData,
            recentActivity,
            recommendations: recommendations.length > 0 ? recommendations : [
                { title: 'Stay Active', content: 'A 30-min walk can boost your mood.', icon: '🏃‍♀️' },
                { title: 'Hydration', content: 'Aim for 2.5L of water today.', icon: '💧' }
            ]
        });

    } catch (error) {
        console.error('Dashboard error:', error);
        res.status(500).json({ success: false, error: error.message });
    }
};

// GET /api/profile/notifications/:userId
exports.getNotifications = async (req, res) => {
    try {
        const user = await User.findById(req.params.userId).select('notifications');
        if (!user) return res.status(404).json({ success: false, error: 'User not found' });

        // Sort by newest first
        const notifications = user.notifications.sort((a, b) => new Date(b.date) - new Date(a.date));

        res.json({
            success: true,
            notifications
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
};

// PUT /api/profile/notifications/mark-read/:userId
exports.markNotificationsRead = async (req, res) => {
    try {
        const user = await User.findById(req.params.userId);
        if (!user) return res.status(404).json({ success: false, error: 'User not found' });

        user.notifications.forEach(n => {
            n.read = true;
        });

        await user.save();

        res.json({
            success: true,
            message: 'All notifications marked as read'
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
};
