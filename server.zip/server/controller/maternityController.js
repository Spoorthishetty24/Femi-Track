const axios = require("axios");
const User = require('../models/User');

const GROQ_API_KEY = process.env.GROQ_API_KEY;

exports.getAITip = async (req, res) => {
    try {
        const { userId, type, date } = req.body; // type: 'nutrition' or 'maternity'

        if (!userId) {
            return res.status(400).json({ success: false, error: "User ID is required" });
        }

        const user = await User.findById(userId);
        if (!user) {
            return res.status(404).json({ success: false, error: "User not found" });
        }

        // Check and Reset Daily Limit
        const todayStr = new Date().toISOString().split('T')[0];
        const lastResetStr = user.cycleInfo.lastTipsResetDate ? new Date(user.cycleInfo.lastTipsResetDate).toISOString().split('T')[0] : "";

        if (todayStr !== lastResetStr) {
            user.cycleInfo.aiTipsCount = 0;
            user.cycleInfo.lastTipsResetDate = new Date();
        }

        if (user.cycleInfo.aiTipsCount >= 10) {
            return res.status(429).json({
                success: false,
                error: "Daily limit reached (10/10 tips). Come back tomorrow! ✨"
            });
        }

        // Personalization Data
        const { profile, cycleInfo, dailyHabits } = user;
        const recentLog = dailyHabits.length > 0 ? dailyHabits[dailyHabits.length - 1] : null;
        const recentMood = recentLog ? recentLog.mood : "normal";
        const recentSymptoms = recentLog ? (recentLog.symptoms || []).join(', ') : "none";

        let prompt = "";
        if (type === 'maternity') {
            if (!cycleInfo.isPregnant) {
                return res.json({ success: true, tip: "Change your status to 'Pregnant' in profile to get maternity advice! 👶" });
            }

            let weekInfo = "";
            if (cycleInfo.pregnancyStartDate) {
                const diffTime = Math.abs(new Date() - new Date(cycleInfo.pregnancyStartDate));
                const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                const weeks = Math.floor(diffDays / 7) + 1;
                weekInfo = `User is in week ${weeks} of pregnancy.`;
            }

            prompt = `You are a maternity health expert. ${weekInfo} Provide a concise, week-wise pregnancy tip or health advice based on medical guidelines. Focus on what's happening this week. Keep it under 60 words. Empathy is key.`;
        } else {
            prompt = `You are a nutrition expert for women's health. Provide a daily nutrition recommendation for a user. 
            Context: Pregnant: ${cycleInfo.isPregnant}, BMI: ${profile.bmi || 'average'}, Recent mood: ${recentMood}, Recent symptoms: ${recentSymptoms}. 
            Keep it actionable and under 60 words. Speak directly to the user.`;
        }

        // Groq API Call
        if (!GROQ_API_KEY) {
            // when running without a real AI key we still want the
            // remaining limit to reflect the 10-tip per day cap
            return res.json({
                success: true,
                tip: `[MOCK TIP] Try adding seeds like flax or pumpkin to your breakfast for better hormonal balance! (Add GROQ_API_KEY to .env for real AI)`,
                limitRemaining: 10 - (user.cycleInfo.aiTipsCount + 1)
            });
        }

        const response = await axios.post(
            "https://api.groq.com/openai/v1/chat/completions",
            {
                model: "llama-3.1-8b-instant",
                messages: [
                    {
                        role: "system",
                        content: prompt
                    },
                    {
                        role: "user",
                        content: "Give me a tip."
                    }
                ],
                temperature: 0.7,
                max_tokens: 150
            },
            {
                headers: {
                    Authorization: `Bearer ${GROQ_API_KEY}`,
                    "Content-Type": "application/json"
                }
            }
        );

        const aiTip = response.data.choices[0].message.content;

        // Save to dailyHabits
        const targetDate = date ? new Date(date).setHours(0, 0, 0, 0) : new Date().setHours(0, 0, 0, 0);
        let log = user.dailyHabits.find(h => new Date(h.date).setHours(0, 0, 0, 0) === targetDate);

        if (!log) {
            log = { date: new Date(targetDate), aiInsights: [] };
            user.dailyHabits.push(log);
            log = user.dailyHabits[user.dailyHabits.length - 1];
        }

        log.aiInsights.push({
            type: type,
            content: aiTip,
            time: new Date()
        });

        // Increment Count
        user.cycleInfo.aiTipsCount += 1;
        await user.save();

        res.json({
            success: true,
            tip: aiTip,
            limitRemaining: 10 - user.cycleInfo.aiTipsCount
        });

    } catch (error) {
        console.error("Maternity Tip Error:", error.response?.data || error.message);
        res.status(500).json({ success: false, error: "AI Service error" });
    }
};
