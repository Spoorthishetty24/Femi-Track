const User = require('../models/User');

// POST /api/games/score
exports.updateScore = async (req, res) => {
    try {
        const { userId, points, gameType } = req.body;

        if (!userId || points === undefined) {
            return res.status(400).json({ success: false, error: "UserId and points are required" });
        }

        const user = await User.findById(userId);
        if (!user) {
            return res.status(404).json({ success: false, error: "User not found" });
        }

        // Update gamification points
        user.gamification.points += points;

        // Level up logic
        if (gameType && user.gamification.gameLevels) {
            const currentLevel = user.gamification.gameLevels[gameType] || 1;
            // For now, simplicity: if they score > some threshold, level up
            // In a real app, the frontend would tell us exact level completed
            if (req.body.levelCompleted && req.body.levelCompleted >= currentLevel) {
                user.gamification.gameLevels[gameType] = req.body.levelCompleted + 1;
            }
        }

        // Simple streak logic: if they play a game, it counts towards their daily activity
        const today = new Date().setHours(0, 0, 0, 0);
        const lastLogin = user.lastLogin ? new Date(user.lastLogin).setHours(0, 0, 0, 0) : 0;

        if (today !== lastLogin) {
            // Check if it's a consecutive day
            const yesterday = new Date(today - 86400000).setHours(0, 0, 0, 0);
            if (lastLogin === yesterday) {
                user.gamification.streak += 1;
            } else {
                user.gamification.streak = 1;
            }
            user.lastLogin = new Date();

            if (user.gamification.streak > user.gamification.longestStreak) {
                user.gamification.longestStreak = user.gamification.streak;
            }
        }

        await user.save();

        res.json({
            success: true,
            totalPoints: user.gamification.points,
            currentStreak: user.gamification.streak
        });

    } catch (error) {
        console.error("Update score error:", error);
        res.status(500).json({ success: false, error: error.message });
    }
};

// GET /api/games/leaderboard
exports.getLeaderboard = async (req, res) => {
    try {
        const topUsers = await User.find({})
            .sort({ 'gamification.points': -1 })
            .limit(10)
            .select('profile.name gamification.points gamification.level');

        const leaderboard = topUsers.map((u, index) => ({
            rank: index + 1,
            name: u?.profile?.name || 'FemiUser',
            points: u?.gamification?.points || 0,
            level: u?.gamification?.level || 1
        }));

        res.json({ success: true, leaderboard });
    } catch (error) {
        console.error("Leaderboard error:", error);
        res.status(500).json({ success: false, error: error.message });
    }
};
