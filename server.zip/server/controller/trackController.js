const User = require('../models/User');
const calculateCycleData = require('../utils/cycleCalculator');

// POST /api/track/log
exports.logDailyData = async (req, res) => {
    try {
        const { userId, date, flow, symptoms, mood, water, sleep, exercise, meditation, pain, isPeriodStart } = req.body;

        // Normalize date to local start of day for comparison
        const logDate = new Date(date);
        logDate.setHours(0, 0, 0, 0);

        // For string comparison, use local date parts to avoid UTC shift
        const dateKey = `${logDate.getFullYear()}-${String(logDate.getMonth() + 1).padStart(2, '0')}-${String(logDate.getDate()).padStart(2, '0')}`;

        const user = await User.findById(userId);
        if (!user) return res.status(404).json({ success: false, error: 'User not found' });

        // Update Cycle Start logic
        if (isPeriodStart) {
            user.cycleInfo.lastPeriodDate = logDate;
            console.log(`[TRACK] User ${user.email} started new cycle on ${logDate}`);
        } else if (flow && flow !== 'none' && !user.cycleInfo.lastPeriodDate) {
            // Auto-set if it's the first ever log
            user.cycleInfo.lastPeriodDate = logDate;
        }

        // Check if log exists for this date
        const existingLogIndex = user.dailyHabits.findIndex(log => {
            const d = new Date(log.date);
            const dKey = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
            return dKey === dateKey;
        });

        const logData = {
            date: logDate,
            flow: flow || 'none',
            symptoms: symptoms || [],
            mood: mood || null,
            waterIntake: water || 0,
            sleepHours: sleep || 0,
            exercise: exercise || false,
            meditation: meditation || false,
            pain: pain || 0
        };

        if (existingLogIndex > -1) {
            // Update existing
            user.dailyHabits[existingLogIndex] = { ...user.dailyHabits[existingLogIndex]._doc, ...logData };
        } else {
            // Add new
            user.dailyHabits.push(logData);

            // Increment points for first log of the day
            user.gamification.points += 10;
        }

        await user.save();

        // Calculate fresh cycle data
        const cycleData = calculateCycleData(
            user.cycleInfo.lastPeriodDate,
            user.cycleInfo.cycleLength,
            user.cycleInfo.periodLength
        );

        res.json({
            success: true,
            message: 'Daily log saved',
            dailyLog: logData,
            points: user.gamification.points,
            cycleData // Return updated predictions
        });

    } catch (error) {
        console.error('Log daily data error:', error);
        res.status(500).json({ success: false, error: error.message });
    }
};

// GET /api/track/:userId
exports.getDailyLogs = async (req, res) => {
    try {
        const user = await User.findById(req.params.userId).select('dailyHabits cycleInfo');
        if (!user) return res.status(404).json({ success: false, error: 'User not found' });

        const cycleData = calculateCycleData(
            user.cycleInfo.lastPeriodDate,
            user.cycleInfo.cycleLength,
            user.cycleInfo.periodLength
        );

        res.json({
            success: true,
            logs: user.dailyHabits,
            cycleData
        });
    } catch (error) {
        console.error('Get logs error:', error);
        res.status(500).json({ success: false, error: error.message });
    }
};
