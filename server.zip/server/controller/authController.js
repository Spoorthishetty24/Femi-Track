const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/User');

exports.register = async (req, res) => {
  try {
    const { email, password, name, height, weight } = req.body;

    // Check existing user
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(409).json({ success: false, error: 'User already exists' });
    }

    // Calculate BMI
    const heightM = height / 100;
    const bmi = parseFloat((weight / (heightM * heightM)).toFixed(2));

    // Create user (no PIN)
    const user = new User({
      email,
      password,
      profile: { name, height, weight, bmi }
    });

    await user.save();

    // JWT Token
    const token = jwt.sign(
      { userId: user._id },
      process.env.JWT_SECRET || 'femitrack-super-secret-2026',
      { expiresIn: '7d' }
    );

    res.status(201).json({
      success: true,
      token,
      user: {
        id: user._id,
        email: user.email,
        name: user.profile.name,
        bmi: user.profile.bmi,
        points: user.gamification.points,
        streak: user.gamification.streak
      }
    });
  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
};

exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;
    console.log(email, password);

    if (!email) {
      return res.json({ success: false, error: 'Email required' });
    }

    if (!password) {
      return res.json({ success: false, error: 'Password required' });
    }

    const user = await User.findOne({ email });
    if (!user) {
      return res.json({ success: false, error: 'User not found' });
    }

    // Only validate password (no PIN)
    const isValid = await user.comparePassword(password);

    if (!isValid) {
      return res.json({ success: false, error: 'Invalid password' });
    }

    // Generate proper JWT token
    const token = jwt.sign(
      { userId: user._id },
      process.env.JWT_SECRET || 'femitrack-super-secret-2026',
      { expiresIn: '7d' }
    );

    res.json({
      success: true,
      token,
      user: {
        id: user._id,
        email: user.email,
        name: user.profile?.name || user.name || 'User',
        bmi: user.profile?.calculatedBMI || user.profile?.bmi || 22.5,
        points: user.gamification?.points || user.points || 0
      }
    });
  } catch (error) {
    console.log(error);
    res.status(500).json({ success: false, error: error.message });
  }
};