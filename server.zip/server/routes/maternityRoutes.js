const express = require('express');
const router = express.Router();
const maternityController = require('../controller/maternityController');

router.post('/ai-tip', maternityController.getAITip);

module.exports = router;
