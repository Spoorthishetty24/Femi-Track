const express = require('express');
const profileController = require('../controller/profileController');
const router = express.Router();

router.get('/:userId', profileController.getProfile);
router.get('/dashboard/:userId', profileController.getDashboard);
router.put('/update/:userId', profileController.updateProfile);
router.put('/cycle-setup/:userId', profileController.saveCycleSetup);
router.get('/notifications/:userId', profileController.getNotifications);
router.put('/notifications/mark-read/:userId', profileController.markNotificationsRead);

module.exports = router;
