const express = require('express');
const router = express.Router();
const gameController = require('../controller/gameController');

router.post('/score', gameController.updateScore);
router.get('/leaderboard', gameController.getLeaderboard);

module.exports = router;
