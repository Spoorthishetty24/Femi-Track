const express = require('express');
const chatController = require('../controller/chatController');
const router = express.Router();

router.post('/message', chatController.handleChatMessage);

module.exports = router;
