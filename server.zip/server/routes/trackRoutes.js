const express = require('express');
const trackController = require('../controller/trackController');
const router = express.Router();

router.post('/log', trackController.logDailyData);
router.get('/:userId', trackController.getDailyLogs);

module.exports = router;
